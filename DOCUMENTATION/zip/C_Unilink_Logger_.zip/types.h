/*************************************************************************
**  Sony Unilink Bus Traffic Logger
**  by Michael Wolf (aka Mr MIC)
**
**  contact: mr.mic@gmx.net or webmaster@mictronics.de
**  homepage: www.mictronics.de
**
**  File types.h
**  This file is part of Unilink_Logger.c
**
**  Revision History
**
**  when         what  who	why
**
**  2003-03-08   1.0   MIC	initial release
**
**************************************************************************/


#ifndef __TYPES_H__
#define __TYPES_H__

//
// basic unsigned types
//
typedef unsigned char     u08;
typedef unsigned int      u16;
typedef unsigned long int u32;

//
// basic signed types
//
typedef signed char     s08;
typedef signed int      s16;
typedef signed long int s32;

typedef unsigned char     bool;

#define true 1
#define false 0

#ifndef NULL
#define NULL    0
#endif

#endif
