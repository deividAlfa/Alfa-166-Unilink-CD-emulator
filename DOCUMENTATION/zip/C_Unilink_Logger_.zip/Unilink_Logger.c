/*************************************************************************
**  Sony Unilink Bus Traffic Logger
**  by Michael Wolf (aka Mr MIC)
**
**  contact: mr.mic@gmx.net or webmaster@mictronics.de
**  homepage: www.mictronics.de
**
**  File Logger_Only.c
**
**  Revision History
**
**  when         what  who	why
**
**  2003-03-09   1.01a MIC	initial (beta) version but without UART support
**  2003-03-10   1.02a MIC	initial (beta) version added UART support,
**                          changed to bit field as flag store
**  2003-03-10   1.03a MIC  first hardware tested version
**  2003-03-12   1.04  MIC  initial release
**                          changed the parity check routine,
**                          now a flag is used to signal a valid packet
**
**  Used develompent tools (download @ www.avrfreaks.net):
**  AvrEdit v3.5
**  AVRGCC v3.02 with avr-libc-20011126 (file avrgcc_20011214a.exe)
**  AvrStudio 4 for simulating and debugging
**
**************************************************************************/
#include <sig-avr.h>
#include <interrupt.h>
#include <progmem.h>
#include <io.h>

#include "types.h"                  // include short types definition file
/*************************************************************************/
// Config your MCU here

#define CPU_CLOCK       7372800		// MCU crystal speed in Hz
//#define CPU_CLOCK       8000000
#define MY_BAUD_RATE    57600		// UART communication speed

/**************************************************************************/
#define UART_BAUDRATE   ((u32)((u32)CPU_CLOCK/(MY_BAUD_RATE*16L)-1))	//calculate baud rate value for UBBR

const u08 c_SPCR    = 0xc4;         // SPI config byte
const u08 c_Timer0_run  =   4;      // run Timer0 with clk/256
const u08 c_Timer0_stop =   0;      // stop Timer0
#if CPU_CLOCK == 8000000
const u08 c_6ms     = 0x45;         // Timer0 value for 6ms @ 8MHz
#else
const u08 c_6ms     = 0x54;         // Timer0 value for 6ms @ 7,3728MHz
#endif

#define b_SS    2                  // Pin SS
#define b_MOSI  5                  // Pin MOSI
#define b_MISO  6                  // Pin MISO
#define b_CLK   7                  // Pin CLK

//*** Global variables ***
volatile struct {                            // use a bit field as flag store
u08 SPI_TX: 1 ;                     // bit 0 : set when SPI is in Tx mode
u08 UNILINK_RX_COMPL : 1 ;          // bit 1 : set when Unilink packet is complete
u08 CHECKSUM_OK : 1 ;               // bit 2 : set if checksum is ok
} flags;                            // declare as flag byte

u08 rxsize = 0;                     // packet size in bytes
u08 bytecount = 0;                  // counter for received bytes
//u08 v_rxdata[16] = {0x10, 0x31, 0xc5, 0xa5, 0xab, 0x19, 0x70, 0x30, 0xf0, 0x00, 0x00, 0x00, 0x00, 0x1c, 0x70, 0x00};
u08 v_rxdata[16];                   // holds the received packet
                                    // byte in packet array locations
#define destaddr 0                  // destination address
#define srcaddr  1                  // source address
#define cmd1     2                  // command 1
#define cmd2     3                  // command 2
#define parity1  4                  // parity 1
#define data     5                  // start of data

//*** Function declaration ***
void UART_INIT(void);               // init UART
void RESET_SPI(void);               // reset SPI after interrupt
void PARITYCHECK(void);             // does a checksum verification on received packet
void UART_TX(void);                 // send valid received packed via UART
void UART_SENDBYTE(u08 Data);       // send one byte via UART

//***********************************************

//*** Interupt service routines ***
// SPI interrupt
INTERRUPT(SIG_SPI)
{
    if (!(flags.SPI_TX))                    // do SPI Rx routine here
    {
        v_rxdata[bytecount] = inp(SPDR); // read byte
        RESET_SPI();                     // reset SPI
        if ((v_rxdata[0] == 0x00) && (bytecount == 0))return;// skip if 1st byte of packet is 0x00
        rxsize = 6;                                    // set packet size to short
        if (v_rxdata[2] >= 0x80) rxsize = 11;          // set packet size to medium
        if (v_rxdata[2] >= 0xC0) rxsize = 16;          // set packet size to long
        bytecount++;
        if (bytecount >= rxsize)                        // if a packet is complete
        {
            bytecount = 0;                              // reset byte counter
            flags.UNILINK_RX_COMPL = true;              // set status flag
        }
    } // end of SPI Rx routine
    else                            // do SPI Tx routine here
    {
        ;
    } // end SPI Tx routine
} //end of SPI interrupt routine

// Main loop
int main(void)
{
	cli();
    cbi (MCUCR, SRE);               // disable external RAM
    outp (0x00, GIMSK);             // disable external interupts

    outp (0x00, PORTA);	            // PortA all low
	outp (0x00, DDRA);	            // PortA all input
    outp (0x00, PORTB);	            // PortB all low
	outp (0x00, DDRB);	            // PortB all input
    outp (0x00, PORTC);	            // PortC all low
	outp (0x00, DDRC);	            // PortC all input
    outp (0x80, PORTD);	            // PortD all low
	outp (0x00, DDRD);	            // PortD all input

    outp (0x00, TIMSK);             // disable Timer0 overflow interrupt
    outp (0x00, TCCR0);             // Stop Timer0
    outp (0x00, TCCR1A);            // Config Timer1
    outp (0x00, TCCR1B);            // Stop Timer1
        
	outp (c_SPCR, SPCR);            /* SPI control register (11000100)
                                    SPI in slave mode, SPI interupt enabled,
                                    SPI speed = Fclk/64
                                    */
    outp (0x40, DDRB);              // MISO as output and low
    outp (0x00, SPDR);

    UART_INIT();                    // init UART
    sei();                          // enable interrupts

    outp (c_6ms, TCNT0);            // load Timer0
    outp (c_Timer0_run, TCCR0);     // start Timer0

    // wait for idle time between two packets, then start receiving
    while(bit_is_clear(TIFR, TOV0))                             // wait for MOSI high for minimum of 6ms
    {                               
        if (bit_is_clear(PINB, b_MOSI)) outp (c_6ms, TCNT0);    // load Timer0 if MOSI is not high
    };// wait until timer0 overflow
    sbi (TIFR, TOV0);                                           // clear timer0 overflow flag
    outp (c_6ms, TCNT0);                                        // load Timer0
    while(bit_is_clear(TIFR, TOV0))                             // wait for MOSI low for minimum of 6ms
    {
        if (bit_is_set(PINB, b_MOSI)) outp (c_6ms, TCNT0);      // load Timer0  if MOSI is not low
    };// wait until timer overflow
    outp (c_Timer0_stop, TCCR0);    // stop timer0
    // now we are going in end endless loop waiting for packets
    while(true)
    {
        while(!(flags.UNILINK_RX_COMPL))
        {
        ;  // wait here until one complete Unilink packet is received
        }; // end of waiting for next packet

        PARITYCHECK();                      // do a parity check of received packet and proceed if OK
        if (flags.CHECKSUM_OK)              
        {
            flags.UNILINK_RX_COMPL = false; // reset packet flag
            UART_TX();                      // send valid packet via UART
        }  // end of routine if parity was ok
        else
        {
            flags.UNILINK_RX_COMPL = false; // reset packet flag
        }; // end packet was invalid
    }; // end of endless while loop
}; // end of main()

//*** Functions ***
void UART_INIT(void)                // init UART
{
        outp(0x18, UCR);
        outp((u08)UART_BAUDRATE, UBRR); // set baud rate
}; // end UART_INIT

void RESET_SPI(void)                // reset SPI
{
        inp (SPSR);
        outp (0x00, SPDR);          // force MISO low
        outp (0x00, SPCR);          // reset SPI interrupt flag
       	outp (c_SPCR, SPCR);        // reconfig SPI
}; //end RESET_SPI

void PARITYCHECK(void)              // check parity of complete Unilink packet
{
        u08 loc_bytecount = 0;      // local byte counter
        u08 loc_rxsize = rxsize-2;  // local rxsize, minus 1 parity and 1 end byte
        u08 loc_checksum = 0;       // local checksum

        for(;loc_bytecount < 4; loc_bytecount++)   // calculate checksum for byte 1-4
        {
            loc_checksum += v_rxdata[loc_bytecount];// add to checksum
        };

        if (loc_checksum == v_rxdata[parity1])     // verify the 1st checksum, skip rest if is invalid
        {
            if (loc_bytecount==loc_rxsize)         // check if short packet
            {
                if (v_rxdata[loc_bytecount+2] == 0x00)
                {
                    flags.CHECKSUM_OK = 1;         // return with true if parity1 is ok AND end byte is 0x00 (short)
                }; // end if end byte
            }; // end if short packet
        } // end if parity ok
        else
        {
            flags.CHECKSUM_OK = 0;                // if parity or end byte is invalid, return false
        }; // end if parity wrong

        loc_bytecount++;            // skip byte 4

        for (;loc_bytecount < loc_rxsize;loc_bytecount++)      // calculate checksum for all other bytes
        {
            loc_checksum += v_rxdata[loc_bytecount];// add to checksum
         //   loc_bytecount++;        // next byte
        };

        if (loc_bytecount == loc_rxsize) // check for medium or long packet
        {
            if (loc_checksum == v_rxdata[loc_bytecount])
            {
                if (v_rxdata[loc_bytecount+1] == 0x00)
                {
                    flags.CHECKSUM_OK = 1;  // return with true if parity2 is ok AND end byte is 0x00 (medium or long)
                }
            }
            else
            {
                flags.CHECKSUM_OK = 0;      // if parity or end byte is invalid return false
            }
        } // end if
} // end PARITYCHECK

void UART_TX(void)
{
        u08 loc_bytecount = 0;      // local byte counter
        u08 loc_rxsize = rxsize;    // local rxsize
        u08 loc_temp = 0;           //local temp

        UART_SENDBYTE(0x0d);        // CR
        UART_SENDBYTE(0xab);        // start tag

        /*
        This routine sends each byte of a packet in 2 ASCII chars via UART.
        Its a simple 8 bit hex to 2 byte ASCII conversion.
        example: 0xff is send as 0x4646 (FF)
        So you can monitor the output with an normal terminal program.
        */
        for (loc_bytecount = 0;loc_bytecount < loc_rxsize;loc_bytecount++)// for a whole packet do:
        {
            loc_temp = v_rxdata[loc_bytecount];
            loc_temp = (loc_temp & 0xF0) >> 4;              // mask higher nibble and shift to lower nibble
            if (loc_temp < 10)
            {
                loc_temp = loc_temp + 48;                   // if lower nibble is lower 10 make 0-9 ASCII char
            }
            else
            {
                loc_temp = loc_temp + 55;                   // if lower nibble is greater 10 make A-F ASCII char
            };
            UART_SENDBYTE(loc_temp);                        // send higher nibble of byte
            loc_temp = v_rxdata[loc_bytecount] & 0x0F;      // mask lower nibble
            if (loc_temp < 10)
            {
                loc_temp = loc_temp + 48;                   // if lower nibble is lower 10 make 0-9 ASCII char
            }
            else
            {
                loc_temp = loc_temp + 55;                   // if lower nibble is greater 10 make A-F ASCII char
            };

            UART_SENDBYTE(loc_temp);                        // send lower nibble of byte

            UART_SENDBYTE(' ');                             // space between hex values
        }; // end for loop

}; // end UART_TX

void UART_SENDBYTE(u08 Data)
{
	while ((inp(USR) & BV(UDRE)) != BV(UDRE));             // wait for UART to become available
    outp(Data, UDR);                                       // send character
}; //end UART_SENDBYTE
