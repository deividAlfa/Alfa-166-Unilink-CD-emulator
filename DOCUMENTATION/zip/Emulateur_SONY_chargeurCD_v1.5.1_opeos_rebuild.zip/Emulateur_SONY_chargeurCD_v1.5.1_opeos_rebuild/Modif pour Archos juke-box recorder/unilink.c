#include <string.h>
#include "kernel.h"
#include "power.h"
#include "serial.h"
#include "id3.h"
#include "mpeg.h"
#include "button.h"
#include "lcd.h"
//#include "cdc.h"

static short last_button=0;
static int   repeat_count=0;
static  char ext_buffer[EXT_BUFWIDTH][EXT_NLINES];
static int  ext_updated[EXT_NLINES];
static int  ext_curline=0;
void cdc_poll(void);

unsigned short cdc_routine2(int button){

    short cur_button=0;
	switch (button) {
    case CDC_POLL       :
        cdc_poll();
        break;
    case CDC_START      :
		mpeg_resume();
        break;
    case CDC_PAUSE      :
		mpeg_pause();
        break;
    case CDC_STOP       :
        power_off();
        break;
    case CDC_NEXT_TRACK :
    case CDC_FORWARD :
        cur_button = BUTTON_RIGHT ;
        break;
    case CDC_PREV_TRACK :
    case CDC_REWIND :
        cur_button = BUTTON_LEFT ;
        break;
    case CDC_NEXT_DISK  :
        cur_button = BUTTON_UP ;
        break;
    case CDC_PREV_DISK  :
        cur_button = BUTTON_DOWN ;
        break;
    case CDC_INTRO      :
        break;
    case CDC_SHUFFLE    :
        cur_button = BUTTON_MENU ;
        break;
    case CDC_REPEAT     :
        cur_button = BUTTON_ON ;
        break;
    case CDC_RELEASE:
        if (last_button) {
            cur_button = last_button | BUTTON_REL;
            last_button = 0;
            return cur_button;
        }
        break;
	}
    if (cur_button) {
        // button pushed
        repeat_count=0;
        last_button = cur_button;
        return cur_button;
    } else if (last_button) {
        // a button was pushed but not released
        repeat_count++;
        if (repeat_count > 30) {
            repeat_count = 20;
            return last_button | BUTTON_REPEAT;
        }
    }

    return 0;
}
void cdc_init(void){
    int a;
    for(a=0;a<EXT_NLINES;a++) {
        ext_buffer[0][a]='\0';
        ext_updated[a]=0;
    }
    ext_curline=0;
}
void ext_set_cursor(int line) {
    ext_curline=line;
    ext_updated[line]=1;
}

void ext_puts(int line,char* str) {
    // update display buffer
    int a;
    int do_update=0;
    for (a=0;a<(EXT_BUFWIDTH-1) && str[a] ;a++) {
        do_update |= (ext_buffer[a][line] != str[a]);
        ext_buffer[a][line] = str[a];
    }
    ext_buffer[a][line]=0;
    ext_updated[line] |= do_update;
}

#define SEND(a) buf[rsp_len++]=a
#define SEND_HEX(a)  SEND((( (a/10) ? a/10 : 0xa ) << 4)  | ( a % 10 ))
#define SEND_HEX0(a) SEND(( (a/10) << 4)  | ( a % 10 ))
void cdc_poll(){
	static unsigned last_elapsed=0;
	static unsigned last_flag   =0;
	static struct mp3entry* last_mp3=0;
	static unsigned cur_flag = 0;
	struct mp3entry* mp3;
	unsigned cur_elapsed;
	char buf[16];
	int rsp_len=0;
	int track_change;
	int track=0;

	// send elapsed time
	mp3 = mpeg_current_track();
	track_change = (mp3 != last_mp3);
	if (mp3) {
		cur_elapsed = mp3->elapsed/1000;
		track       = mp3->index+1;
	} else {
		cur_elapsed = -1;
	}
	if ((cur_elapsed != last_elapsed)) {
		int hour = (cur_elapsed/60);
		int min  = (cur_elapsed%60);
		// update track & time
		SEND(1);
        if ((signed)cur_elapsed == -1) {
            // no current track
            SEND( 0 );
            SEND( 0xdd );
            SEND( 0xdd );
            SEND( 0xdd );
        } else {
			if (track < 16) {
				SEND(  track );
			} else {
				SEND(  15 );
			}
            SEND_HEX(  track);
            SEND_HEX(  hour );
            SEND_HEX0( min  );
        }
		last_elapsed = cur_elapsed;
	} else if (last_flag != cur_flag) {
		SEND(4);
		SEND((cur_flag >> 0) & 0xff);
		SEND((cur_flag >> 8) & 0xff);
		SEND((cur_flag >> 16) & 0xff);
		SEND((cur_flag >> 24) & 0xff);
		last_flag = cur_flag;
	} else if (ext_updated[ext_curline]) {
		int a;
		SEND(2);
		for(a=0;ext_buffer[a][ext_curline] && (a<EXT_DISPLAY_WIDTH);a++) {
			char ch=ext_buffer[a][ext_curline];
			switch(ch) {
			case '�':
			case '�':
			case '�':
			case '�':
				SEND('e');
				break;
			case '�':
				SEND('a');
				break;
			case '�':
				SEND('c');
				break;
			default:
				SEND(ch);
			}
		}
		while(a<EXT_DISPLAY_WIDTH) {
			SEND(' ');
			a++;
		}
        ext_updated[ext_curline]=0;
	} else {
		// nothing to update send nothing...
		//SEND(0);
	}
	serial_soft_tx_data(buf,rsp_len);
}
