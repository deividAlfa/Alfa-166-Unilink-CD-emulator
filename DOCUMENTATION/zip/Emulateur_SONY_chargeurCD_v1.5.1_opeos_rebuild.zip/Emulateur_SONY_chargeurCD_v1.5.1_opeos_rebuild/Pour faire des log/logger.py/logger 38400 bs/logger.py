#!python
import sys
import re
import serial

ByteValues=[
    'RAD', 'TAD', 'CMD1', 'CMD2', 'PAR1', 'D1', 'D2', 'D3',
    'D4', 'D2_1', 'D2_2', 'D2_3', 'D2_4' , 'D2_5'
    ]

def toInt(s):
	s=s.strip()
	if s[:2] == '0x':
		return int(s,16)
	else:
		return int(s)

def RTADToStr(Byte):
	if   Byte == 0x10        : Result = 'MASTER'
	elif Byte == 0x11        : Result = 'KEYPAD'
	elif Byte == 0x18        : Result = 'B-CAST'
	elif Byte == 0x21        : Result = 'KEYCTL'
	elif Byte & 0xF0 == 0x30 : Result = 'CD_'	+ str(Byte-0x30)     
	elif Byte & 0xF0 == 0x50 : Result = 'TUNER'	+ str(Byte-0x50)   
	elif Byte & 0xF0 == 0x60 : Result = 'TAPE_'	+ str(Byte-0x60)   
	elif Byte & 0xF0 == 0x70 : Result = 'DISP_'	+ str(Byte-0x70)   
	elif Byte & 0xF0 == 0x80 : Result = 'BUS_MUX_'  + str(Byte-0x80)
	elif Byte & 0xF0 == 0x90 : Result = 'DSP_'	+ str(Byte-0x90)    
	elif Byte & 0xF0 == 0xC0 : Result = 'CLOCK'	+ str(Byte-0xC0)   
	elif Byte & 0xF0 == 0xD0 : Result = 'MD_'	+ str(Byte-0xD0)     
	else : Result='Unknown(%02X)'%Byte
	
	return Result.ljust(9)

def displayHex2(cmd):
	for a in cmd:
		sys.stdout.write( '%02X '%a)
		
def displayHex(cmd):
	for a in cmd:
		sys.stdout.write( '%02X '%a)
	for a in range(16-len(cmd)):
		sys.stdout.write( '   ')
	sys.stdout.write( '// ')
	for a in cmd:
		c=chr(a)
		if c.isalnum():
			x=c
		else:
			x='.'
		sys.stdout.write(x)
	for a in range(16-len(cmd)):
		sys.stdout.write( ' ')
		
	sys.stdout.write(': '+RTADToStr(cmd[1])+' to '+RTADToStr(cmd[0])+' : ')
	
class Cmd:
	def __init__(self):
		self.conds=[]
	def addCond(self,cond):
		byteMask = cond[0].split('&')
		if len(byteMask)>1:
			mask=toInt(byteMask[1])
		else :
			mask=0xff
		byte=ByteValues.index(byteMask[0])
		val=toInt(cond[1])
		self.conds.append((byte,mask,val))
	def parseDisp(self,disp):
		a=disp.split('<')
		self.disp=[a[0]]
		self.exps=[]
		exp=re.compile('[=\[\]&+-]')
		for b in a[1:]:
			b=b.split('>')
			if len(b)!=2:
				print 'problem with '+b
				raise Error
			#b[0] contains an expression to be parsed
			val=b[0]
			ops=[]
			oper=[]
			op=exp.search(val)
			while(op is not None):
				ops.append(op.group(0))
				x=exp.split(val,maxsplit=1)
				val=x[1]
				oper.append(x[0])
				op=exp.search(val)
			oper.append(val)
			self.exps.append((oper,ops))
			self.disp.append(b[1])
		#print disp,' >>'
		#print self.disp
		#print self.exps
	def printDesc(self,cmd):
		for a in range(len(self.disp)):
			sys.stdout.write(self.disp[a])
			if len(self.exps)> a:
				exp=self.exps[a]
				val=cmd[ByteValues.index(exp[0][0])]
				for b in range(len(exp[1])):
					op=exp[1][b]
					oper=exp[0][b+1]
					if op=='=':
						if oper=='a':
							if chr(val).isalnum():
								c=chr(val)
							else:
								c='.'
							sys.stdout.write(c)
							break
						elif oper=='h2':
							sys.stdout.write(("%02X"%val).replace('F','0'))
							break
						elif oper=='d':
							sys.stdout.write(("%d"%val))
							break
						else :
							sys.stdout.write("0x%02X"%val)
							break
					elif op in '[]+-&':
						oper=toInt(oper)
						if op == '[':
							val = val << oper
						elif op == ']' :
							val = val >> oper
						elif op == '+' :
							val = val + oper
						elif op == '-' :
							val = val - oper
						elif op == '&' :
							val = val & oper
					else:
						sys.stdout.write("??%02X %s %s"%(val,op,oper))
						break
				else:
					sys.stdout.write("0x%02X"%val)
		print	
		
class CmdFile:
	def __init__(self,name):
		f=open(name,'r')
		l=f.readlines()
		self.commands=[]
		for a in l:
			b=a.split('//')[0].split(':',1)
			if len(b)==1: continue
			cmd=b[0].strip()
			disp=b[1].strip()
			#print cmd,'\t',disp
			# parse command conditions
			c=cmd.split('<')
			curCmd = Cmd()
			for condTmp in c[1:]:
				cond = condTmp.split('>')[0].split('=')
				curCmd.addCond(cond)
			#print curCmd.conds
			curCmd.parseDisp(disp)
			self.commands.append(curCmd)
			
	def displayCmd(self,cmd):
		# cmd is a framed array of byte
		for cond in self.commands:
			for a in cond.conds:
				if cmd[a[0]] & a[1] == a[2]:
					continue
				else:
					break
			else:
				# cond matching display infos
				displayHex(cmd)
				cond.printDesc(cmd)
				break
		else:
			displayHex(cmd)
			print '??UNKNOWN?? cmd1=0x%02X cmd2=0x%02X'%(cmd[2],cmd[3])
			
class Framer:
	def __init__(self,cmdfilename='commands.txt'):
		self.cmdFile = CmdFile(cmdfilename)
		self.framed=1
		self.cmd=[]
	def decodeByte(self,b):
		self.cmd.append(b)
		#print self.cmd
		l=len(self.cmd)
		if l==5 or (l>5 and not self.framed):
			# check parity1
			par=0
			for a in range(4):
				par += self.cmd[l-5+a]
			ok = (par&0xff) == b
			if not self.framed and ok:
				# frame found: skip first bytes
				skip=self.cmd[:l-5]
				self.cmd = self.cmd[l-5:]
				displayHex2(skip)
				print ' // skipping unknown bytes'
			self.framed=ok
		elif l > 5:
			# should be framed
			if   self.cmd[2]<0x80:
				cs= 6
			elif self.cmd[2]<0xC0:
				cs= 11
			else :
				cs=16
			if l==cs:
				# short cmd, b should be 0
				if b != 0 :
					displayHex2(self.cmd)
					print '// command not ending with 0, drop all frame'
					self.cmd=[]
					return
				else:
					#ok check parity 2
					par=0
					if cs > 6:
						for a in range(4,cs-2):
							par+=self.cmd[a]
						ok=	(par&0xff) == self.cmd[cs-2]
						if not ok:
							displayHex2(self.cmd)
							print '// parity2 error, drop all frame'
							self.cmd=[]
							return
					# should be a valid frame
					self.cmdFile.displayCmd(self.cmd)
					self.cmd=[]
						
					
a=Framer()
if sys.argv[1][:3]=='com':
	dev=int(sys.argv[1][3])
	baud=19200
	l=sys.argv[1].split(':')
	if len(l)==2:
		baud=int(l[1])
	dbg = len(l)==3
		
	ser=serial.Serial(dev,baud)
	while(1):
		x=ser.read()
		if dbg:
			print '%02X '%x
		else:
			a.decodeByte(ord(x))
else:
	f=open(sys.argv[1],'r')
	l=f.readlines()
	for b in l:
		if len(b)< 3:
			continue
		comments=b.split('//',1)
		c=comments[0][1:].split(' ')
		cmd=[]
		for d in c:
			try:
				a.decodeByte(int(d.strip(),16))
			except ValueError:
				continue
