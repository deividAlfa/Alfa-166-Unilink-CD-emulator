jQuery(document).ready(function() {
   jQuery('a.highslide').click(function() {
	   return hs.expand(this);
	});
});

